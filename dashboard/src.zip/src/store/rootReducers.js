import authReducer from "./Reducers/authReducer"

const rootReducer = {
    auth: authReducer
}

export default rootReducer